<?php
require_once "interface/formatinterface.php";
require_once "libarary/formatlibarary.php";
require_once "model/buku.php";
require_once "model/peminjaman.php";
require_once "view/tampilan.php";
require_once "controller/peminjamancontroller.php";

$controller = new PeminjamanController();
$controller->tampilkanData();
?>