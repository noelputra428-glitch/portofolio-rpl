<?php
class Peminjaman extends FormatLibrary {
    public $buku;
    public $peminjam;

    public function __construct($buku, $peminjam) {
        $this->buku = $buku;
        $this->peminjam = $peminjam;
    }

    public function tampilkanData() {
        echo "<b>DATA PEMINJAMAN</b><br>";
        echo "Buku : " . $this->buku->judul . " oleh " . $this->buku->penulis . "<br>";
        echo "Tahun Terbit : " . $this->buku->tahunTerbit . "<br>";
        echo "Peminjam : " . $this->peminjam . "<br>";
        $this->formatTampilan();
    }
}
?>