<?php
class Tampilan {
    public function tampilkan($dataPeminjaman) {
        foreach ($dataPeminjaman as $peminjaman) {
            $peminjaman->tampilkanData();
        }
    }
}
?>