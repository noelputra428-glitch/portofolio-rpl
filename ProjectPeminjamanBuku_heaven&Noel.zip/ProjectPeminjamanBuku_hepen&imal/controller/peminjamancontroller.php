<?php
class PeminjamanController {
    public function tampilkanData() {
        $buku1 = new Buku("Pemrograman OOP dengan PHP", "Indra Kurnia", 2023);
        $peminjaman1 = new Peminjaman($buku1, "Rifki");

        $buku2 = new Buku("Harry Potter by J.K. Rowling", "J.K. Rowling", 2011);
        $peminjaman2 = new Peminjaman($buku2, "Umar Hadi");

        $view = new Tampilan();
        $view->tampilkan([$peminjaman1, $peminjaman2]);
    }
}
?>