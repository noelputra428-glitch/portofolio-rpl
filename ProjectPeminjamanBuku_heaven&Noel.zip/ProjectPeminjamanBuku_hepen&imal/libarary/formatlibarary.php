<?php
class FormatLibrary implements FormatInterface {
    public function formatTampilan() {
        echo "<hr>";
    }
}
?>