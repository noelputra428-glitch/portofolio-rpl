<?php
interface FormatInterface {
    public function formatTampilan();
}
?>